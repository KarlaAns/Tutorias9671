//****************//
//**Universidad de Las Fuerzas Armadas ESPE**//
//Estudiante: Karla Ansatuña, Alejandro Cuadrado, Matias Suarez, Jefferson Ulco
//Materia: Estructura de Datos
//NRC:9671
//Descripcion del codigo:
// Matriz cifrada mediante MD5 y suma de su respectivo codigo hexadecimal
//****************//
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <sstream>
#include "md5.h"

int main() {
  // Inicializar la semilla del generador de números aleatorios
  std::srand(std::time(0));

  // Definir la matriz de 4x4
  int matriz[4][4];
  int sumaAsciiMatriz[4][4];
  int sumaDigitosMatriz[4][4];
  int sumaColumnas[4] = {0};
  int sumaDigitosColumnas[4] = {0};

  // Llenar la matriz con números aleatorios entre 0 y 9
  for (int i = 0; i < 4; ++i) {
    for (int j = 0; j < 4; ++j) {
      matriz[i][j] = std::rand() % 10;
    }
  }

  // Lambda para calcular el hash MD5 de un número
  auto calcularHash = [](int numero) {
    std::stringstream ss;
    ss << numero;
    MD5 md5(ss.str());
    return md5.hexdigest();
  };

  std::cout << "\nNumero, cifrado completo, cifrado limitado y codigo ASCII:\n";
  for (int i = 0; i < 4; ++i) {
    for (int j = 0; j < 4; ++j) {
      int numero = matriz[i][j];
      std::string cifradoCompleto = calcularHash(numero);
      std::string cifradoLimitado = cifradoCompleto.substr(0, 4);
      int sumaAscii = 0;
      int sumaDigitos = 0;
      std::cout << "\nNumero: " << numero << " - Cifrado completo: " << cifradoCompleto << " - Cifrado limitado: " << cifradoLimitado << std::endl;
      std::cout << "Codigos ASCII del cifrado limitado: ";
      for (char c : cifradoLimitado) {
        int asciiValue = static_cast<int>(c);
        sumaAscii += asciiValue;
        std::cout << asciiValue << " ";
      }
      std::cout << "\nSuma de codigos ASCII: " << sumaAscii << std::endl;
      sumaAsciiMatriz[i][j] = sumaAscii;

      // Sumar los dígitos del resultado ASCII
      while (sumaAscii != 0) {
        sumaDigitos += sumaAscii % 10;
        sumaAscii /= 10;
      }
      sumaDigitosMatriz[i][j] = sumaDigitos;
      std::cout << "Suma de los digitos del codigo ASCII: " << sumaDigitos  << std::endl;

      // Sumar los valores en la misma columna
      sumaColumnas[j] += sumaDigitos;
    }
  }
   

  // Sumar los dígitos de las sumas de las columnas
  for (int i = 0; i < 4; ++i) {
    int columnaSuma = sumaColumnas[i];
    while (columnaSuma != 0) {
      sumaDigitosColumnas[i] += columnaSuma % 10;
      columnaSuma /= 10;
    }
  }

  // Mostrar la matriz inicial
  std::cout << "\nMatriz inicial:\n";
  for (int i = 0; i < 4; ++i) {
    for (int j = 0; j < 4; ++j) {
      std::cout << matriz[i][j] << "\t";
    }
    std::cout << std::endl;
  }

  // Mostrar la matriz de sumas ASCII
  std::cout << "\nMatriz de sumas de codigos ASCII:\n";
  for (int i = 0; i < 4; ++i) {
    for (int j = 0; j < 4; ++j) {
      std::cout << sumaAsciiMatriz[i][j] << "\t";
    }
    std::cout << std::endl;
  }

  // Mostrar la matriz de sumas de dígitos
  std::cout << "\nMatriz de sumas de los digitos de los codigos ASCII:\n";
  for (int i = 0; i < 4; ++i) {
    for (int j = 0; j < 4; ++j) {
      std::cout << sumaDigitosMatriz[i][j] << "\t";
    }
    std::cout << std::endl;
  }
  
std::cout << "\nSumas de los numeros en la misma columna y suma especial de sus digitos:\n";

int sumasEspeciales[2] = {0, 0};

for (int i = 0; i < 4; ++i) {
  int sumaDigitos = 0;

  // Sumar los dígitos de la columna
  int suma = sumaColumnas[i];
  while (suma != 0) {
    sumaDigitos += suma % 10;
    suma /= 10;
  }

  std::cout << "Columna " << i+1 << ": " << sumaColumnas[i] << " - Suma de digitos: " << sumaDigitos << std::endl;

  // Sumar los dígitos de acuerdo con el patrón dado
  if (i % 2 == 0) {
    sumasEspeciales[0] += sumaDigitos;
  } else {
    sumasEspeciales[1] += sumaDigitos;
  }
}

std::cout << "\nSuma de los digitos de las columnas impares: " << sumasEspeciales[0] << std::endl;
std::cout << "\nSuma de los digitos de las columnas pares: " << sumasEspeciales[1] << std::endl;

int sumaTotal = sumasEspeciales[0] + sumasEspeciales[1];
std::cout << "\nSuma de los digitos de la suma de las columnas impares y pares: " << sumaTotal << std::endl;

int resultadoRestaCifras = sumaTotal % 10; // Tomar el primer dígito

// Ahora restar el resto de los dígitos
int copiaSumaTotal = sumaTotal / 10;
while (copiaSumaTotal != 0) {
    resultadoRestaCifras -= copiaSumaTotal % 10;
    copiaSumaTotal /= 10;
}

std::cout << "\nResultado de restar las cifras de la suma total: " << resultadoRestaCifras << std::endl;

  return 0;
}


