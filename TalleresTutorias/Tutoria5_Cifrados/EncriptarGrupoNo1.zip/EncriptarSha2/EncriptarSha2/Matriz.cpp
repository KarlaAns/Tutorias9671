/***********************************************************************
 * UNIVERSIDAD DE LAS FUERZAS ARMADAS - ESPE
 * Module:  main.cpp
 * Author:  Milena Maldonado, Alexander Guaman, Ronny Ibarra, Sebastian Rivera
 * Modified:  Lunes, Julio 17, 2023 18:24:36
 * Purpose: Cifrar una matriz
 ***********************************************************************/

#include "Matriz.h"

using namespace std;

void Matriz::setDimension(int newDimension) {
	dimension = newDimension;
}

int Matriz::getDimension() {
	return dimension;
}

int **Matriz::crearMatriz() {
	int **matriz;
	matriz = new int *[getDimension()];

	for (int i = 0; i < getDimension(); i++) {
		matriz[i] = new int[getDimension()];
	}
	return matriz;
}


void Matriz::llenar_tablero(int **matriz) {
	srand(time(NULL));
	for (int fila = 0; fila < getDimension(); fila++) {
		for (int columna = 0; columna < getDimension(); columna++) {
			int num_aleatorio = rand() % 100;
			*(*(matriz + fila) + columna) = num_aleatorio;
		}
	}
}

void Matriz::imprimir_tablero(int **matriz) {
	for (int fila = 0; fila < getDimension(); fila++) {
		for (int columna = 0; columna < getDimension(); columna++) {
			cout << *(*(matriz + fila) + columna) << " ";
		}
		cout << endl;
	}
}


int Matriz::ingresarEnteros() {
	char *dato = new char[10];
	int i = 0;
	int numero;
	char c;
	while ((c = _getch()) != 13) {

		if (c >= '0' && c <= '9') {

			dato[i++] = c;
			printf("%c", c);
			numero = atoi(dato);
		} else if (c == 8) {

			dato[i] = 0;
			i--;

			putchar(8);
			putchar(32);
			putchar(8);
		}
	}
	dato[i] = '\0';
	return numero;
}


int Matriz::pedirDimension() {
	int tamanio;
	do {
		system("CLS");
		cout << "Ingrese la dimension del tablero: ";
		tamanio = ingresarEnteros();
		cout << endl;
	} while (tamanio < 2 || tamanio > 8);
	return tamanio;
}


int Matriz::cifrarMatriz(int** matriz)
{
	int cifrado = 0;

	for (int i = 0; i < getDimension(); i++)
	{
		for (int j = 0; j < getDimension(); j++)
		{
			*(*(matriz + i) + j) = sumarDigitos(*(*(matriz + i) + j));
			cifrado += *(*(matriz + i) + j);
		}

		cifrado = sumarDigitos(cifrado);
	}

	return cifrado;
}



int** Matriz::cifrarMatrizSimpleHash(int** matriz, int rows, int cols) {
	auto simpleHash = [](int value) {
		// M�scara para limitar el resultado del hash a 32 bits
		const int mask = 0xFFFFFFFF;

		// Operaci�n XOR para mezclar los bits del valor
		value = ((value >> 16) ^ value) * 0x45D9F3B;
		value = ((value >> 16) ^ value) * 0x45D9F3B;
		value = (value >> 16) ^ value;

		return value & mask;
	};
	
	int** hashMatriz = new int* [rows];
	for (int i = 0; i < rows; ++i) {
		hashMatriz[i] = new int[cols];
		for (int j = 0; j < cols; ++j) {
			int value = *(*(matriz + i) + j);
			int hashedValue = simpleHash(value);
			*(*(hashMatriz + i) + j) = hashedValue;
		}
	}

	return hashMatriz;
}

int Matriz::sumarDigitos(int n) {
	int suma = 0;
	while (n > 0) {
		suma += n % 10;
		n /= 10;
	}
	return (suma < 10) ? suma : sumarDigitos(suma);
}
