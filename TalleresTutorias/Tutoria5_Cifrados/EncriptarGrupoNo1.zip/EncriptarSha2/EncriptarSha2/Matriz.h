#ifndef MATRIZ_H
#define MATRIZ_H

/***********************************************************************
 * UNIVERSIDAD DE LAS FUERZAS ARMADAS - ESPE
 * Module:  main.cpp
 * Author:  Milena Maldonado, Alexander Guaman, Ronny Ibarra, Sebastian Rivera
 * Modified:  Lunes, Julio 17, 2023 18:24:36
 * Purpose: Cifrar una matriz
 ***********************************************************************/

#include <iostream>
#include <time.h>
#include <conio.h>

using namespace std;

class Matriz {
	private:
		int dimension;

	public:
		void setDimension(int);
		int getDimension();
		int **crearMatriz();
		void llenar_tablero(int **);
		void imprimir_tablero(int **);
		int ingresarEnteros();
		int pedirDimension();
		int** cifrarMatrizSimpleHash(int**, int, int);
		int cifrarMatriz(int**);
		int sumarDigitos(int);
};

#endif
