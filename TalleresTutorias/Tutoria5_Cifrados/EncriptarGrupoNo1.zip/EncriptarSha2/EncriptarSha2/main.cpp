/***********************************************************************
 * UNIVERSIDAD DE LAS FUERZAS ARMADAS - ESPE
 * Module:  main.cpp
 * Author:  Milena Maldonado, Alexander Guaman, Ronny Ibarra, Sebastian Rivera
 * Modified:  Lunes, Julio 17, 2023 18:24:36
 * Purpose: Cifrar una matriz
 ***********************************************************************/

#include "Matriz.h"
#include <iostream>

using namespace std;

int main() {
	Matriz T;
	int **matriz;
	int **matriz2;
	int dim;
	int cifrado =0;

	dim = T.pedirDimension();
	T.setDimension(dim);
	matriz = T.crearMatriz();
	matriz2 = T.crearMatriz();
	T.llenar_tablero(matriz);
	cout << endl << "MATRIZ ORIGINAL " << endl;
	T.imprimir_tablero(matriz);
	cout << endl << "MATRIZ CIFRADA " << endl;
	matriz2 = T.cifrarMatrizSimpleHash(matriz,dim,dim);
	T.imprimir_tablero(matriz2);
	cifrado = T.cifrarMatriz(matriz2);
	cout << endl << "Suma resultante: " << cifrado << endl << endl ;

	system("PAUSE");

	return 0;
}