//****************//
//**Universidad de Las Fuerzas Armadas ESPE**//
//Estudiante: Karla Ansatuña, Alejandro Cuadrado, Matias Suarez, Jefferson Ulco, Milena Maldonado, 
//Alexander Guaman, Martin Suquillo, Sebastian Rivera, Carlos Campoverde, Ariel Pozo, Ronny Ibarra
//Materia: Estructura de Datos
//NRC:9671
//Descripcion del codigo:
// Dos caballos se posicionan aleatoriamente en el tablero de ajedrez, el programa nos dice y nos
//grafica en que parte uno de los caballos comera al otro 
//****************//
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <graphics.h>
#include "reinas.cpp"  

using namespace std;
void generarMovimientoCaballo(int filaActual, int colActual, int &nuevaFila, int &nuevaCol, int N) {
    int movimientosFila[] = {2, 1, -1, -2, -2, -1, 1, 2};
    int movimientosCol[] = {1, 2, 2, 1, -1, -2, -2, -1};

    int indiceMovimiento = rand() % 8; // Seleccionar uno de los 8 posibles movimientos en forma de "L"
    
    nuevaFila = filaActual + movimientosFila[indiceMovimiento];
    nuevaCol = colActual + movimientosCol[indiceMovimiento];

    if (nuevaFila < 0 || nuevaFila >= N || nuevaCol < 0 || nuevaCol >= N) {
        generarMovimientoCaballo(filaActual, colActual, nuevaFila, nuevaCol, N);
    }
}
void guardarMovimientoSoluciones(int filaBlanco, int colBlanco, int filaNegro, int colNegro, int N, int movimiento) {
    ofstream archivo_soluciones("soluciones.txt", ios::app);
    archivo_soluciones << "Movimiento " << movimiento << ":\n";
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (i == filaBlanco && j == colBlanco)
                archivo_soluciones << "B";
            else if (i == filaNegro && j == colNegro)
                archivo_soluciones << "N";
          
            else if ((i + j) % 2 == 0)
                archivo_soluciones << ".";
            else
                archivo_soluciones << "#";
        }
        archivo_soluciones << "\n";
    }
    archivo_soluciones << "\n";
    archivo_soluciones.close();
}

void dibujarReina(int row, int col)
{
    readimagefile("reina.jpg", col * 50, row * 50, (col + 1) * 50, (row + 1) * 50);
}
int main() {
    borrar_archivo();
    int N;
    cout << "Ingrese la dimension del tablero: ";
    cin >> N;
    ofstream archivo_tablero("tablero.txt");
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if ((i + j) % 2 == 0)
                archivo_tablero << ".";
            else
                archivo_tablero << "#";
        }
        archivo_tablero << "\n";
    }
    archivo_tablero << "\n";
    archivo_tablero.close();
    srand(static_cast<unsigned int>(time(0)));
    int randomFilaBlanco = rand() % N;
    int randomColBlanco = rand() % N;
    colocarCaballoNegroAleatoria(randomFilaBlanco, randomColBlanco);

    int randomFilaNegro = rand() % N;
    int randomColNegro = rand() % N;
    colocarCaballoRojoAleatoria(randomFilaNegro, randomColNegro);

    int windowSize = 50 * N; 
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");
    initwindow(windowSize, windowSize); 

    dibujarTableroDesdeTxt(N);
    dibujarCaballoNegro(randomFilaBlanco, randomColBlanco);
    dibujarCaballoRojo(randomFilaNegro, randomColNegro);

    int moves = 0;
    while (!caballosAtacan(randomFilaBlanco, randomColBlanco, randomFilaNegro, randomColNegro)) {
        int newRandomFilaBlanco, newRandomColBlanco;
        generarMovimientoCaballo(randomFilaBlanco, randomColBlanco, newRandomFilaBlanco, newRandomColBlanco, N);
        colocarCaballoNegroAleatoria(newRandomFilaBlanco, newRandomColBlanco);
        dibujarCaballoNegro(newRandomFilaBlanco, newRandomColBlanco);
        delay(2); 
        int newRandomFilaNegro, newRandomColNegro;
        generarMovimientoCaballo(randomFilaNegro, randomColNegro, newRandomFilaNegro, newRandomColNegro, N);
        colocarCaballoRojoAleatoria(newRandomFilaNegro, newRandomColNegro);
        dibujarCaballoRojo(newRandomFilaNegro, newRandomColNegro);
        delay(2); 
        guardarMovimientoSoluciones(randomFilaBlanco, randomColBlanco, randomFilaNegro, randomColNegro, N, moves);
        randomFilaBlanco = newRandomFilaBlanco;
        randomColBlanco = newRandomColBlanco;
        randomFilaNegro = newRandomFilaNegro;
        randomColNegro = newRandomColNegro;
        if ((randomFilaBlanco == randomFilaNegro && randomColBlanco == randomColNegro) || (randomFilaBlanco == newRandomFilaNegro && randomColBlanco == newRandomColNegro)) {
            cout << "Colision en: Fila " << randomFilaBlanco << ", Columna " << randomColBlanco << endl;
            dibujarReina(randomFilaBlanco,randomColBlanco);
			break;
        }
        moves++;
    }
    cout << "Los caballos se comeran despues de " << moves << " movimientos." << endl;
    getch();
    closegraph();
    return 0;
}