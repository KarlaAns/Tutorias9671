//****************//
//**Universidad de Las Fuerzas Armadas ESPE**//
//Estudiante: Karla Ansatuña, Alejandro Cuadrado, Matías Suárez, Jefferson Ulco, Milena Maldonado, 
//Alexander Guaman, Martín Suquillo, Sebastian Rivera, Carlos Campoverde, Ariel Pozo, Ronny Ibarra
//Materia: Estructura de Datos
//NRC:9671
//Descripcion del codigo:
// Dos caballos se posicionan aleatoriamente en el tablero de ajedrez, el programa nos dice y nos
//grafica en que parte uno de los caballos comera al otro 
//****************//
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <graphics.h>
#include "reinas.h"

using namespace std;

void colocarCaballoNegroAleatoria(int row, int col)
{
    int N = row + 1;
    int columna[MAX_N];
    for (int i = 0; i < N; i++)
    {
        if (i == row)
            columna[i] = col;
        else
            columna[i] = -1;
    }
}

void colocarCaballoRojoAleatoria(int row, int col)
{
    int N = row + 1;
    int columna[MAX_N];
    for (int i = 0; i < N; i++)
    {
        if (i == row)
            columna[i] = col;
        else
            columna[i] = -1;
    }
}

void dibujarCaballoRojo(int row, int col)
{
    // Cargar imagen del caballo rojo
    readimagefile("caballoRojo.jpg", col * 50, row * 50, (col + 1) * 50, (row + 1) * 50);
}

void dibujarCaballoNegro(int row, int col)
{
    // Cargar imagen del caballo negro
    readimagefile("caballoNegro.jpg", col * 50, row * 50, (col + 1) * 50, (row + 1) * 50);
}

bool esMovimientoValido(int fila1, int columna1, int fila2, int columna2)
{
    int df = abs(fila1 - fila2);
    int dc = abs(columna1 - columna2);

    return (df == 2 && dc == 1) || (df == 1 && dc == 2);
}

bool caballosAtacan(int fila1, int columna1, int fila2, int columna2)
{
    int df = abs(fila1 - fila2);
    int dc = abs(columna1 - columna2);

    return (df == 2 && dc == 1) || (df == 1 && dc == 2);
}

void dibujarTableroDesdeTxt(int N)
{
    ifstream archivo("tablero.txt");
    int i = 0;
    string line;
    while (getline(archivo, line))
    {
        for (int j = 0; j < N; j++)
        {
            if (line[j] == '.')
                setfillstyle(SOLID_FILL, LIGHTBLUE);
            else
                setfillstyle(SOLID_FILL, BLUE);

            bar(j * 50, i * 50, (j + 1) * 50, (i + 1) * 50);
        }
        i++;
    }
    archivo.close();
}

void borrar_archivo()
{
    ofstream archivo("soluciones.txt", ios::trunc);
    archivo.close();
    
    ofstream archivo2("tablero.txt", ios::trunc);
    archivo2.close();
}
