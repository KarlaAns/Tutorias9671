//****************//
//**Universidad de Las Fuerzas Armadas ESPE**//
//Estudiante: Karla Ansatuña, Alejandro Cuadrado, Matías Suárez, Jefferson Ulco, Milena Maldonado, 
//Alexander Guaman, Martín Suquillo, Sebastian Rivera, Carlos Campoverde, Ariel Pozo, Ronny Ibarra
//Materia: Estructura de Datos
//NRC:9671
//Descripcion del codigo:
// Dos caballos se posicionan aleatoriamente en el tablero de ajedrez, el programa nos dice y nos
//grafica en que parte uno de los caballos comera al otro 
//****************//
#ifndef REINAS_H
#define REINAS_H

const int MAX_N = 100;  // Define MAX_N aquí

void colocarCaballoNegroAleatoria(int row, int col);
void colocarCaballoRojoAleatoria(int row, int col);
void dibujarCaballoNegro(int row, int col);
void dibujarCaballoRojo(int row, int col);
bool esMovimientoValido(int fila1, int columna1, int fila2, int columna2);
bool caballosAtacan(int fila1, int columna1, int fila2, int columna2);
void dibujarTableroDesdeTxt(int N);
void borrar_archivo();

#endif
