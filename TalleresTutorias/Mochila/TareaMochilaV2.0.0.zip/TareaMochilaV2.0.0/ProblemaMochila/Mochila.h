//****************//
//**Universidad de Las Fuerzas Armadas ESPE**//
//Estudiante: Matias Suarez, Karla Ansatuña, Alejandro Cuadrado, Jefferson Ulco
//Materia: Estructura de Datos
//NRC:9671
//Descripcion del codigo:
//Problema de la mochila con memoria dinamica y recursividad
//****************//

#include <algorithm> 
#pragma once

class Mochila{
	private:
		int  nElementos;
		int* peso;
		int* beneficio;
		int  capacidad;
	public:
		Mochila(int*,int*,int,int);
		int capacidadMaxima(int*,int*,int,int);
		int resolver();	
};
