//****************//
//**Universidad de Las Fuerzas Armadas ESPE**//
//Estudiante: Matias Suarez, Karla Ansatuña, Alejandro Cuadrado, Jefferson Ulco
//Materia: Estructura de Datos
//NRC:9671
//Descripcion del codigo:
//Problema de la mochila con memoria dinamica y recursividad
//****************//

#include <iostream>
#include "Mochila.h"
#include "Validaciones.cpp"
using namespace std;

/**
 * @brief Función principal del programa.
 *
 * Realiza las siguientes tareas:
 *
 * - Verifica la capacidad y el número de objetos.
 * - Declara e inicializa los arreglos de beneficio y peso.
 * - Lee los valores de beneficio y peso de los objetos.
 * - Crea un objeto de la clase Mochila.
 * - Resuelve el problema de la mochila.
 * - Verifica si la mochila aún tiene espacio para ser llenada.
 *
 * @return 0 si el programa se ejecuta correctamente, o 1 si ocurre un error.
 */
int main() {
  cout << "\t\t===PROBLEMA DE LA MOCHILA===" << endl;
  /**
   * Verifica la capacidad de la mochila.
   */
  int capacidad;
  do {
    cout << "\n>Ingrese la capacidad de la mochila:";
    cin >> capacidad;
  } while (!verificarCapacidad(capacidad));
  /**
   * Verifica el número de objetos.
   */
  int numObjetos;
  do {
    cout << "\n>Ingrese el numero de objetos que desea guardar:";
    cin >> numObjetos;
  } while (!verificarNumObjetos(numObjetos));
  /**
   * Declara e inicializa los arreglos de beneficio y peso.
   */
  int* beneficio = new int[numObjetos];
  int* peso = new int[numObjetos];
  for (int i = 0; i < numObjetos; i++) {
    beneficio[i] = -1;
    peso[i] = -1;
  }
  
  /**
   * Lee los valores de beneficio y peso de los objetos.
   */
  for (int j = 0; j < numObjetos; j++) {
    cout << "\nObjeto [" << j + 1 << "]:" << endl;
    cout << "\n>Ingrese el beneficio:";
    cin >> beneficio[j];
    cout << "\n>Ingrese el peso:";
    cin >> peso[j];
  }
  
  /**
   * Crea un objeto de la clase Mochila.
   */
  Mochila m(peso, beneficio, numObjetos, capacidad);

  /**
   * Resuelve el problema de la mochila.
   */
  cout << "\n<< Beneficio maximo de la mochila: " << m.resolver() << " >>";
  /**
   * Verifica si la mochila aún tiene espacio para ser llenada.
   */
  if (capacidad > m.resolver()) {
    cout << "\n>La mochila aun tiene espacio para ser llenada" << endl;
  }

  return 0;
}
