//****************//
//**Universidad de Las Fuerzas Armadas ESPE**//
//Estudiante: Matias Suarez, Karla Ansatuña, Alejandro Cuadrado, Jefferson Ulco
//Materia: Estructura de Datos
//NRC:9671
//Descripcion del codigo:
//Problema de la mochila con memoria dinamica y recursividad
//****************//

#include"Mochila.h"
#include <climits>

Mochila::Mochila(int* auxPeso,int* auxBenef,int auxElementos,int auxCapacidad){
	this->peso=auxPeso;
	this->beneficio=auxBenef;
	this->nElementos=auxElementos;
	this->capacidad=auxCapacidad;
}

int Mochila::capacidadMaxima(int* auxBenef, int* auxPeso, int _n, int auxCapacidad){
    if (auxCapacidad < 0) {
        return INT_MIN;
    }
    if (_n < 0 || auxCapacidad == 0) {
        return 0;
    }
    int incluir = *(auxBenef+_n) + capacidadMaxima(auxBenef, auxPeso, _n - 1, auxCapacidad - *(auxPeso+_n));
    int excluir = capacidadMaxima(auxBenef, auxPeso, _n - 1, auxCapacidad);
    return std::max(incluir, excluir);
}

int Mochila::resolver(){
	return capacidadMaxima(beneficio, peso, nElementos-1, capacidad);
}
