//****************//
//**Universidad de Las Fuerzas Armadas ESPE**//
//Estudiante: Matias Suarez, Karla Ansatuña, Alejandro Cuadrado, Jefferson Ulco
//Materia: Estructura de Datos
//NRC:9671
//Descripcion del codigo:
//Problema de la mochila con memoria dinamica y recursividad
//****************//

#include <iostream>
#include "Mochila.cpp"

bool esNumero(std::string numero) {
  for (int i = 0; i < numero.length(); i++) {
    if (!isdigit(numero[i])) {
      return false;
    }
  }
  return true;
}

bool verificarCapacidad(int capacidad) {
  if (capacidad < 0) {
  	std::cout << "\n\n\t<<Ingrese nuevamente el valor>>"<< std::endl;
    std::cout << "\n\n\t\t<<la capacidad de la mochila debe ser mayor o igual que cero>>" << std::endl;
    return false;
  }
  return true;
}

bool verificarNumObjetos(int numObjetos) {
  if (numObjetos < 0) {
  	std::cout << "\n\n\t<<Ingrese nuevamente el valor>>"<< std::endl;
    std::cout << "\n\n\t\t<<El número de objetos debe ser mayor o igual que cero>>" << std::endl;
    return false;
  }
  return true;
}