/*
	UFA-ESPE
	Alumnos:  Sebastian Rivera
	Enunciado: Realizar el Problema de la Mochila
	Nivel.- 3   NRC: 9671
*/


#include <algorithm> 
#pragma once

class Mochila{
	private:
		int  nElementos;
		int* peso;
		int* beneficio;
		int  capacidad;
	public:
		Mochila();
		Mochila(int*,int*,int,int);
		int capacidadMaxima(int*,int*,int,int);
		int resolver();	
};
