/*
	UFA-ESPE
	Alumnos:  Sebastian Rivera
	Enunciado: Realizar el Problema de la Mochila
	Nivel.- 3   NRC: 9671
*/

#include <iostream>
#include "Mochila.cpp"
using namespace std;
 
int main(){
	std::cout<<"\t\t**PROBLEMA DE LA MOCHILA**"<<endl;
    int capacidad=0,numObj=0,benef=0,pesoDat=0;
	int cap=0,n=0;	
    std::cout<<"\n>Ingrese la capacidad de la mochila:";
    std::cin>>capacidad;
    if(capacidad==false){
		std::cout<<"\n\n\t\t<<ERROR - No se permite ingreso de Letras>>"<<endl;
		system("pause");
		exit(0);
	}	
    cap = capacidad;
    cout<<endl;
    
    std::cout<<">Ingrese el numero de objetos que guardara:";
    std::cin>>numObj;
    if(numObj==false){
		std::cout<<"\n\n\t\t<<ERROR - No se permite ingreso de Letras>>"<<endl;
		system("pause");
		exit(0);
	}
    n = numObj;
    cout<<endl;

    int* beneficio=new int[n];
    int* peso=new int[n];
    *beneficio=-1;
    *peso=-1;

    for(int i=0;i<n;i++){
    	*(beneficio+i)=-1;
    	*(peso+i)=-1;
	}

    for(int j=0;j<n;j++){
    	std::cout<<"\nObjeto ["<<j+1<<"]:";
        std::cout<<"\n>Ingrese el beneficio:";
        std::cin>>benef;
        if(benef==false){
			std::cout<<"\n\n\t\t<<ERROR - No se permite ingreso de Letras>>"<<endl;
			system("pause");
			exit(0);
		}
    	*(beneficio+j) = benef;    		
        
        std::cout<<">Ingrese el peso:";
        std::cin>>pesoDat;
        if(pesoDat==false){
			std::cout<<"\n\n\t\t<<ERROR - No se permite ingreso de Letras>>"<<endl;
			system("pause");
			exit(0);
		}
        *(peso+j) = pesoDat;
	}
    
	Mochila m(peso,beneficio,n,cap);
    std::cout << "\n<< Beneficio maximo de la mochila: " << m.resolver()<<" >>";
    
    if (capacidad>m.resolver())
    {
        std::cout<<"\n>La mochila aun tiene espacio para ser llenada"<<endl;
    }

    return 0;
}
