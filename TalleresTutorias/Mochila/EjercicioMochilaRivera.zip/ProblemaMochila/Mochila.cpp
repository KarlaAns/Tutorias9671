/*
	UFA-ESPE
	Alumnos:  Sebastian Rivera
	Enunciado: Realizar el Problema de la Mochila
	Nivel.- 3   NRC: 9671
*/


#include"Mochila.h"
#include <climits>

Mochila::Mochila(int* auxPeso,int* auxBenef,int auxElementos,int auxCapacidad){
	this->peso=auxPeso;
	this->beneficio=auxBenef;
	this->nElementos=auxElementos;
	this->capacidad=auxCapacidad;
}

int Mochila::capacidadMaxima(int* auxBenef, int* auxPeso, int _n, int auxCapacidad){
    if (auxCapacidad < 0) {
        return INT_MIN;
    }
    if (_n < 0 || auxCapacidad == 0) {
        return 0;
    }
    int incluir = *(auxBenef+_n) + capacidadMaxima(auxBenef, auxPeso, _n - 1, auxCapacidad - *(auxPeso+_n));
    int excluir = capacidadMaxima(auxBenef, auxPeso, _n - 1, auxCapacidad);
    return std::max(incluir, excluir);
}

int Mochila::resolver(){
	return capacidadMaxima(beneficio, peso, nElementos-1, capacidad);
}
